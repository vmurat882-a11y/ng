"use client";

import { useState } from "react";
import { Sidebar } from "@/components/nginx-ui/sidebar";
import { Header } from "@/components/nginx-ui/header";
import { DashboardView } from "@/components/nginx-ui/dashboard-view";
import { SitesView } from "@/components/nginx-ui/sites-view";
import { StreamsView } from "@/components/nginx-ui/streams-view";
import { ConfigView } from "@/components/nginx-ui/config-view";
import { CertificatesView } from "@/components/nginx-ui/certificates-view";
import { TerminalView } from "@/components/nginx-ui/terminal-view";
import { EnvironmentView } from "@/components/nginx-ui/environment-view";

const titles: Record<string, string> = {
  dashboard: "Dashboard",
  sites: "Sites",
  streams: "Streams",
  config: "Configuration",
  certificates: "SSL Certificates",
  terminal: "Terminal",
  environment: "Environment",
  settings: "Settings",
};

export default function NginxUI() {
  const [activeTab, setActiveTab] = useState("dashboard");

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardView />;
      case "sites":
        return <SitesView />;
      case "streams":
        return <StreamsView />;
      case "config":
        return <ConfigView />;
      case "certificates":
        return <CertificatesView />;
      case "terminal":
        return <TerminalView />;
      case "environment":
        return <EnvironmentView />;
      case "settings":
        return (
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            Settings panel coming soon...
          </div>
        );
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={titles[activeTab] || "Dashboard"} />
        <main className="flex-1 overflow-y-auto p-6 bg-background">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
