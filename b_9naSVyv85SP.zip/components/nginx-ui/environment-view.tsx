"use client";

import {
  HardDrive,
  Cpu,
  MemoryStick,
  Network,
  Server,
  Clock,
  Thermometer,
  Zap,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const diskData = [
  { name: "/", used: 128, total: 200, color: "oklch(0.72 0.19 145)" },
  { name: "/var", used: 234, total: 500, color: "oklch(0.65 0.2 250)" },
  { name: "/home", used: 45, total: 100, color: "oklch(0.75 0.15 85)" },
  { name: "/tmp", used: 2, total: 50, color: "oklch(0.7 0.2 300)" },
];

const cpuCores = [
  { core: "Core 0", usage: 45 },
  { core: "Core 1", usage: 32 },
  { core: "Core 2", usage: 58 },
  { core: "Core 3", usage: 21 },
  { core: "Core 4", usage: 67 },
  { core: "Core 5", usage: 38 },
  { core: "Core 6", usage: 52 },
  { core: "Core 7", usage: 29 },
];

const networkInterfaces = [
  { name: "eth0", ip: "192.168.1.100", mac: "00:1B:44:11:3A:B7", status: "up" },
  { name: "eth1", ip: "10.0.0.50", mac: "00:1B:44:11:3A:B8", status: "up" },
  { name: "lo", ip: "127.0.0.1", mac: "00:00:00:00:00:00", status: "up" },
  { name: "docker0", ip: "172.17.0.1", mac: "02:42:AC:11:00:01", status: "down" },
];

export function EnvironmentView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-foreground">Environment</h2>
        <p className="text-sm text-muted-foreground">
          Server hardware and system information
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">CPU Temperature</p>
                <p className="text-2xl font-semibold text-foreground mt-1">52°C</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <Thermometer className="w-6 h-6 text-chart-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Load Average</p>
                <p className="text-2xl font-semibold text-foreground mt-1">0.08</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">0.08, 0.03, 0.01</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Uptime</p>
                <p className="text-2xl font-semibold text-foreground mt-1">17 days</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <Clock className="w-6 h-6 text-chart-2" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">7 hours, 32 minutes</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Processes</p>
                <p className="text-2xl font-semibold text-foreground mt-1">142</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center">
                <Server className="w-6 h-6 text-chart-4" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">2 running, 140 sleeping</p>
          </CardContent>
        </Card>
      </div>

      {/* CPU Cores */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Cpu className="w-4 h-4 text-chart-2" />
            CPU Core Usage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cpuCores} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" horizontal={false} />
                <XAxis type="number" domain={[0, 100]} stroke="oklch(0.65 0.01 260)" fontSize={12} unit="%" />
                <YAxis dataKey="core" type="category" stroke="oklch(0.65 0.01 260)" fontSize={12} width={60} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "oklch(0.17 0.015 260)",
                    border: "1px solid oklch(0.28 0.015 260)",
                    borderRadius: "8px",
                    color: "oklch(0.95 0 0)",
                  }}
                  formatter={(value: number) => [`${value}%`, "Usage"]}
                />
                <Bar dataKey="usage" radius={[0, 4, 4, 0]}>
                  {cpuCores.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.usage > 50 ? "oklch(0.65 0.2 25)" : "oklch(0.72 0.19 145)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Disk & Memory */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-primary" />
              Disk Partitions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {diskData.map((disk) => (
              <div key={disk.name}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{disk.name}</span>
                  <span className="text-sm text-muted-foreground">
                    {disk.used} GB / {disk.total} GB
                  </span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${(disk.used / disk.total) * 100}%`,
                      backgroundColor: disk.color,
                    }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <MemoryStick className="w-4 h-4 text-chart-3" />
              Memory Usage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Physical Memory</span>
                <span className="text-sm text-muted-foreground">4.8 GB / 16 GB</span>
              </div>
              <div className="h-3 bg-secondary rounded-full overflow-hidden flex">
                <div className="h-full bg-chart-3" style={{ width: "30%" }} />
                <div className="h-full bg-chart-2/50" style={{ width: "19%" }} />
              </div>
              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-chart-3" />
                  <span>Used (4.8 GB)</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-chart-2/50" />
                  <span>Buffers/Cache (3.0 GB)</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-secondary" />
                  <span>Free (8.2 GB)</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Swap</span>
                <span className="text-sm text-muted-foreground">0 B / 2 GB</span>
              </div>
              <div className="h-3 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-chart-4" style={{ width: "0%" }} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Network Interfaces */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Network className="w-4 h-4 text-chart-2" />
            Network Interfaces
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Interface</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">IP Address</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">MAC Address</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {networkInterfaces.map((iface) => (
                  <tr key={iface.name} className="border-b border-border last:border-0">
                    <td className="py-3 px-4 font-medium text-foreground">{iface.name}</td>
                    <td className="py-3 px-4 text-muted-foreground font-mono">{iface.ip}</td>
                    <td className="py-3 px-4 text-muted-foreground font-mono">{iface.mac}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full ${
                          iface.status === "up"
                            ? "bg-primary/10 text-primary"
                            : "bg-secondary text-muted-foreground"
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            iface.status === "up" ? "bg-primary" : "bg-muted-foreground"
                          }`}
                        />
                        {iface.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* System Info */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium">System Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Hostname</p>
              <p className="text-foreground font-medium mt-1">nginx-server-01</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Operating System</p>
              <p className="text-foreground font-medium mt-1">Ubuntu 22.04.3 LTS</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Kernel</p>
              <p className="text-foreground font-medium mt-1">5.15.0-91-generic</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Architecture</p>
              <p className="text-foreground font-medium mt-1">x86_64</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">CPU Model</p>
              <p className="text-foreground font-medium mt-1">Intel Xeon E5-2680 v4</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">CPU Cores</p>
              <p className="text-foreground font-medium mt-1">8 cores @ 2.40GHz</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
