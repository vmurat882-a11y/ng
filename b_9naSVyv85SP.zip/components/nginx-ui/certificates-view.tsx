"use client";

import { useState } from "react";
import {
  Shield,
  Plus,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Calendar,
  Clock,
  MoreVertical,
  Download,
  Trash2,
  ExternalLink,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface Certificate {
  id: string;
  domain: string;
  issuer: string;
  status: "valid" | "expiring" | "expired";
  issuedAt: string;
  expiresAt: string;
  autoRenew: boolean;
}

const initialCertificates: Certificate[] = [
  {
    id: "1",
    domain: "example.com",
    issuer: "Let's Encrypt Authority X3",
    status: "valid",
    issuedAt: "2024-01-15",
    expiresAt: "2025-04-15",
    autoRenew: true,
  },
  {
    id: "2",
    domain: "api.example.com",
    issuer: "Let's Encrypt Authority X3",
    status: "valid",
    issuedAt: "2024-01-15",
    expiresAt: "2025-04-15",
    autoRenew: true,
  },
  {
    id: "3",
    domain: "blog.example.com",
    issuer: "Let's Encrypt Authority X3",
    status: "expiring",
    issuedAt: "2023-10-20",
    expiresAt: "2024-01-20",
    autoRenew: true,
  },
  {
    id: "4",
    domain: "old.example.com",
    issuer: "Let's Encrypt Authority X3",
    status: "expired",
    issuedAt: "2023-07-01",
    expiresAt: "2023-10-01",
    autoRenew: false,
  },
  {
    id: "5",
    domain: "admin.example.com",
    issuer: "Let's Encrypt Authority X3",
    status: "valid",
    issuedAt: "2024-01-10",
    expiresAt: "2025-04-10",
    autoRenew: true,
  },
];

export function CertificatesView() {
  const [certificates, setCertificates] = useState<Certificate[]>(initialCertificates);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newDomain, setNewDomain] = useState("");

  const filteredCertificates = certificates.filter((cert) =>
    cert.domain.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusIcon = (status: Certificate["status"]) => {
    switch (status) {
      case "valid":
        return <CheckCircle2 className="w-5 h-5 text-primary" />;
      case "expiring":
        return <AlertTriangle className="w-5 h-5 text-chart-3" />;
      case "expired":
        return <XCircle className="w-5 h-5 text-destructive" />;
    }
  };

  const getStatusLabel = (status: Certificate["status"]) => {
    switch (status) {
      case "valid":
        return "Valid";
      case "expiring":
        return "Expiring Soon";
      case "expired":
        return "Expired";
    }
  };

  const renewCertificate = (id: string) => {
    setCertificates((prev) =>
      prev.map((cert) =>
        cert.id === id
          ? {
              ...cert,
              status: "valid",
              issuedAt: new Date().toISOString().split("T")[0],
              expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
                .toISOString()
                .split("T")[0],
            }
          : cert
      )
    );
  };

  const deleteCertificate = (id: string) => {
    setCertificates((prev) => prev.filter((cert) => cert.id !== id));
  };

  const addCertificate = () => {
    if (newDomain.trim()) {
      setCertificates((prev) => [
        {
          id: String(Date.now()),
          domain: newDomain.trim(),
          issuer: "Let's Encrypt Authority X3",
          status: "valid",
          issuedAt: new Date().toISOString().split("T")[0],
          expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
            .toISOString()
            .split("T")[0],
          autoRenew: true,
        },
        ...prev,
      ]);
      setNewDomain("");
      setIsAddDialogOpen(false);
    }
  };

  const stats = {
    total: certificates.length,
    valid: certificates.filter((c) => c.status === "valid").length,
    expiring: certificates.filter((c) => c.status === "expiring").length,
    expired: certificates.filter((c) => c.status === "expired").length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">SSL Certificates</h2>
          <p className="text-sm text-muted-foreground">
            Manage SSL/TLS certificates with automatic renewal
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Issue Certificate
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Issue SSL Certificate</DialogTitle>
              <DialogDescription>
                Automatically obtain and configure a Let&apos;s Encrypt certificate.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="cert-domain">Domain Name</Label>
                <Input
                  id="cert-domain"
                  placeholder="example.com"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  className="bg-secondary border-border"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={addCertificate}>Issue Certificate</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Total</p>
            <p className="text-2xl font-semibold text-foreground mt-1">{stats.total}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Valid</p>
            <p className="text-2xl font-semibold text-primary mt-1">{stats.valid}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Expiring Soon</p>
            <p className="text-2xl font-semibold text-chart-3 mt-1">{stats.expiring}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Expired</p>
            <p className="text-2xl font-semibold text-destructive mt-1">{stats.expired}</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search certificates..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 bg-secondary border-border"
        />
      </div>

      {/* Certificates List */}
      <div className="grid gap-4">
        {filteredCertificates.map((cert) => (
          <Card key={cert.id} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center",
                      cert.status === "valid" && "bg-primary/10",
                      cert.status === "expiring" && "bg-chart-3/10",
                      cert.status === "expired" && "bg-destructive/10"
                    )}
                  >
                    {getStatusIcon(cert.status)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{cert.domain}</span>
                      <span
                        className={cn(
                          "text-xs px-2 py-0.5 rounded-full",
                          cert.status === "valid" && "bg-primary/10 text-primary",
                          cert.status === "expiring" && "bg-chart-3/10 text-chart-3",
                          cert.status === "expired" && "bg-destructive/10 text-destructive"
                        )}
                      >
                        {getStatusLabel(cert.status)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{cert.issuer}</p>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="hidden md:flex items-center gap-6">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>Issued: {cert.issuedAt}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>Expires: {cert.expiresAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2"
                      onClick={() => renewCertificate(cert.id)}
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span className="hidden sm:inline">Renew</span>
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4 text-muted-foreground" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem className="gap-2">
                          <ExternalLink className="w-4 h-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2">
                          <Download className="w-4 h-4" />
                          Download
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="gap-2 text-destructive"
                          onClick={() => deleteCertificate(cert.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                          Revoke
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredCertificates.length === 0 && (
          <Card className="bg-card border-border">
            <CardContent className="p-8 text-center">
              <Shield className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No certificates found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
