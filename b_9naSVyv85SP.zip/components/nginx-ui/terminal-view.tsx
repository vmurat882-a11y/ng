"use client";

import { useState, useRef, useEffect } from "react";
import { Terminal as TerminalIcon, X, Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface TerminalLine {
  type: "input" | "output" | "error";
  content: string;
  timestamp: Date;
}

interface Tab {
  id: string;
  name: string;
  history: TerminalLine[];
}

const mockCommands: Record<string, string | string[]> = {
  "nginx -v": "nginx version: nginx/1.24.0",
  "nginx -t":
    "nginx: the configuration file /etc/nginx/nginx.conf syntax is ok\nnginx: configuration file /etc/nginx/nginx.conf test is successful",
  "systemctl status nginx": [
    "● nginx.service - A high performance web server and reverse proxy server",
    "     Loaded: loaded (/lib/systemd/system/nginx.service; enabled; vendor preset: enabled)",
    "     Active: active (running) since Mon 2024-01-15 08:00:00 UTC; 2 weeks 3 days ago",
    "       Docs: man:nginx(8)",
    "   Main PID: 1234 (nginx)",
    "      Tasks: 5 (limit: 4648)",
    "     Memory: 12.5M",
    "        CPU: 2min 34.521s",
    "     CGroup: /system.slice/nginx.service",
    "             ├─1234 nginx: master process /usr/sbin/nginx -g daemon on; master_process on;",
    "             └─1235 nginx: worker process",
  ].join("\n"),
  "ls -la /etc/nginx": [
    "total 72",
    "drwxr-xr-x   8 root root  4096 Jan 15 08:00 .",
    "drwxr-xr-x 101 root root  4096 Jan 15 08:00 ..",
    "drwxr-xr-x   2 root root  4096 Jan 15 08:00 conf.d",
    "-rw-r--r--   1 root root  1077 Jan 15 08:00 fastcgi.conf",
    "-rw-r--r--   1 root root  1007 Jan 15 08:00 fastcgi_params",
    "-rw-r--r--   1 root root  2837 Jan 15 08:00 koi-utf",
    "-rw-r--r--   1 root root  2223 Jan 15 08:00 koi-win",
    "-rw-r--r--   1 root root  5349 Jan 15 08:00 mime.types",
    "drwxr-xr-x   2 root root  4096 Jan 15 08:00 modules-available",
    "drwxr-xr-x   2 root root  4096 Jan 15 08:00 modules-enabled",
    "-rw-r--r--   1 root root  1482 Jan 15 08:00 nginx.conf",
    "drwxr-xr-x   2 root root  4096 Jan 15 08:00 sites-available",
    "drwxr-xr-x   2 root root  4096 Jan 15 08:00 sites-enabled",
    "drwxr-xr-x   2 root root  4096 Jan 15 08:00 snippets",
    "-rw-r--r--   1 root root   636 Jan 15 08:00 uwsgi_params",
    "-rw-r--r--   1 root root   664 Jan 15 08:00 win-utf",
  ].join("\n"),
  whoami: "root",
  pwd: "/root",
  date: new Date().toString(),
  uptime:
    " 15:32:45 up 17 days,  7:32,  2 users,  load average: 0.08, 0.03, 0.01",
  "free -h": [
    "               total        used        free      shared  buff/cache   available",
    "Mem:            16Gi       4.8Gi       8.2Gi       256Mi       3.0Gi        10Gi",
    "Swap:          2.0Gi          0B       2.0Gi",
  ].join("\n"),
  "df -h": [
    "Filesystem      Size  Used Avail Use% Mounted on",
    "/dev/sda1       200G  128G   62G  68% /",
    "/dev/sda2       500G  234G  241G  50% /var",
    "tmpfs           7.9G     0  7.9G   0% /dev/shm",
  ].join("\n"),
  clear: "",
  help: [
    "Available commands:",
    "  nginx -v          - Show Nginx version",
    "  nginx -t          - Test Nginx configuration",
    "  systemctl status nginx - Show Nginx service status",
    "  ls -la /etc/nginx - List Nginx config directory",
    "  whoami            - Show current user",
    "  pwd               - Show current directory",
    "  date              - Show current date/time",
    "  uptime            - Show system uptime",
    "  free -h           - Show memory usage",
    "  df -h             - Show disk usage",
    "  clear             - Clear terminal",
    "  help              - Show this help message",
  ].join("\n"),
};

export function TerminalView() {
  const [tabs, setTabs] = useState<Tab[]>([
    {
      id: "1",
      name: "Terminal 1",
      history: [
        {
          type: "output",
          content: "Welcome to Nginx UI Terminal\nType 'help' for available commands.\n",
          timestamp: new Date(),
        },
      ],
    },
  ]);
  const [activeTab, setActiveTab] = useState("1");
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  const currentTab = tabs.find((t) => t.id === activeTab);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [currentTab?.history]);

  const handleCommand = (cmd: string) => {
    const trimmedCmd = cmd.trim().toLowerCase();
    
    setTabs((prev) =>
      prev.map((tab) => {
        if (tab.id !== activeTab) return tab;

        const newHistory = [...tab.history];
        
        // Add input line
        newHistory.push({
          type: "input",
          content: cmd,
          timestamp: new Date(),
        });

        // Handle clear command
        if (trimmedCmd === "clear") {
          return { ...tab, history: [] };
        }

        // Get response
        const response = mockCommands[trimmedCmd];
        if (response !== undefined) {
          if (response) {
            newHistory.push({
              type: "output",
              content: typeof response === "string" ? response : response,
              timestamp: new Date(),
            });
          }
        } else {
          newHistory.push({
            type: "error",
            content: `Command not found: ${cmd}\nType 'help' for available commands.`,
            timestamp: new Date(),
          });
        }

        return { ...tab, history: newHistory };
      })
    );

    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && input.trim()) {
      handleCommand(input);
    }
  };

  const addTab = () => {
    const newId = String(Date.now());
    setTabs((prev) => [
      ...prev,
      {
        id: newId,
        name: `Terminal ${prev.length + 1}`,
        history: [
          {
            type: "output",
            content: "Welcome to Nginx UI Terminal\nType 'help' for available commands.\n",
            timestamp: new Date(),
          },
        ],
      },
    ]);
    setActiveTab(newId);
  };

  const closeTab = (id: string) => {
    if (tabs.length === 1) return;
    
    setTabs((prev) => prev.filter((t) => t.id !== id));
    if (activeTab === id) {
      setActiveTab(tabs[0].id === id ? tabs[1].id : tabs[0].id);
    }
  };

  return (
    <Card className="bg-card border-border h-[calc(100vh-180px)] flex flex-col overflow-hidden">
      {/* Tabs */}
      <CardHeader className="py-0 px-0 border-b border-border">
        <div className="flex items-center">
          {tabs.map((tab) => (
            <div
              key={tab.id}
              className={cn(
                "flex items-center gap-2 px-4 py-3 border-r border-border cursor-pointer",
                activeTab === tab.id ? "bg-background" : "bg-card hover:bg-secondary"
              )}
              onClick={() => setActiveTab(tab.id)}
            >
              <TerminalIcon className="w-4 h-4 text-primary" />
              <span className="text-sm text-foreground">{tab.name}</span>
              {tabs.length > 1 && (
                <button
                  className="ml-2 p-0.5 rounded hover:bg-secondary"
                  onClick={(e) => {
                    e.stopPropagation();
                    closeTab(tab.id);
                  }}
                >
                  <X className="w-3 h-3 text-muted-foreground" />
                </button>
              )}
            </div>
          ))}
          <Button
            variant="ghost"
            size="icon"
            className="h-full rounded-none px-3"
            onClick={addTab}
          >
            <Plus className="w-4 h-4 text-muted-foreground" />
          </Button>
        </div>
      </CardHeader>

      {/* Terminal Content */}
      <CardContent
        ref={terminalRef}
        className="flex-1 p-4 overflow-y-auto bg-background font-mono text-sm"
        onClick={() => inputRef.current?.focus()}
      >
        {currentTab?.history.map((line, i) => (
          <div key={i} className="mb-1">
            {line.type === "input" ? (
              <div className="flex items-center gap-2">
                <span className="text-primary">root@nginx-ui:~$</span>
                <span className="text-foreground">{line.content}</span>
              </div>
            ) : (
              <pre
                className={cn(
                  "whitespace-pre-wrap",
                  line.type === "error" ? "text-destructive" : "text-muted-foreground"
                )}
              >
                {line.content}
              </pre>
            )}
          </div>
        ))}
        
        {/* Input Line */}
        <div className="flex items-center gap-2">
          <span className="text-primary">root@nginx-ui:~$</span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent text-foreground outline-none"
            autoFocus
          />
        </div>
      </CardContent>
    </Card>
  );
}
