"use client";

import { useState } from "react";
import {
  Boxes,
  Plus,
  MoreVertical,
  CheckCircle2,
  XCircle,
  Pencil,
  Trash2,
  Power,
  ArrowRight,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface Stream {
  id: string;
  name: string;
  protocol: "tcp" | "udp";
  listenPort: number;
  upstream: string;
  status: "enabled" | "disabled";
  lastModified: string;
}

const initialStreams: Stream[] = [
  {
    id: "1",
    name: "MySQL Proxy",
    protocol: "tcp",
    listenPort: 3306,
    upstream: "db.internal:3306",
    status: "enabled",
    lastModified: "2024-01-15",
  },
  {
    id: "2",
    name: "Redis Cluster",
    protocol: "tcp",
    listenPort: 6379,
    upstream: "redis.internal:6379",
    status: "enabled",
    lastModified: "2024-01-12",
  },
  {
    id: "3",
    name: "PostgreSQL",
    protocol: "tcp",
    listenPort: 5432,
    upstream: "postgres.internal:5432",
    status: "disabled",
    lastModified: "2024-01-10",
  },
  {
    id: "4",
    name: "DNS Resolver",
    protocol: "udp",
    listenPort: 53,
    upstream: "dns.internal:53",
    status: "enabled",
    lastModified: "2024-01-08",
  },
  {
    id: "5",
    name: "SMTP Relay",
    protocol: "tcp",
    listenPort: 25,
    upstream: "mail.internal:25",
    status: "enabled",
    lastModified: "2024-01-05",
  },
];

export function StreamsView() {
  const [streams, setStreams] = useState<Stream[]>(initialStreams);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newStream, setNewStream] = useState({
    name: "",
    protocol: "tcp" as "tcp" | "udp",
    listenPort: "",
    upstream: "",
  });

  const filteredStreams = streams.filter(
    (stream) =>
      stream.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stream.upstream.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleStreamStatus = (id: string) => {
    setStreams((prev) =>
      prev.map((stream) =>
        stream.id === id
          ? {
              ...stream,
              status: stream.status === "enabled" ? "disabled" : "enabled",
            }
          : stream
      )
    );
  };

  const deleteStream = (id: string) => {
    setStreams((prev) => prev.filter((stream) => stream.id !== id));
  };

  const addStream = () => {
    if (newStream.name && newStream.listenPort && newStream.upstream) {
      setStreams((prev) => [
        {
          id: String(Date.now()),
          name: newStream.name,
          protocol: newStream.protocol,
          listenPort: parseInt(newStream.listenPort),
          upstream: newStream.upstream,
          status: "disabled",
          lastModified: new Date().toISOString().split("T")[0],
        },
        ...prev,
      ]);
      setNewStream({ name: "", protocol: "tcp", listenPort: "", upstream: "" });
      setIsAddDialogOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Streams</h2>
          <p className="text-sm text-muted-foreground">
            Manage TCP/UDP stream proxies and load balancers
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Stream
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Add New Stream</DialogTitle>
              <DialogDescription>
                Create a new TCP/UDP stream proxy configuration.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="stream-name">Name</Label>
                <Input
                  id="stream-name"
                  placeholder="MySQL Proxy"
                  value={newStream.name}
                  onChange={(e) =>
                    setNewStream((prev) => ({ ...prev, name: e.target.value }))
                  }
                  className="bg-secondary border-border"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="protocol">Protocol</Label>
                  <Select
                    value={newStream.protocol}
                    onValueChange={(value: "tcp" | "udp") =>
                      setNewStream((prev) => ({ ...prev, protocol: value }))
                    }
                  >
                    <SelectTrigger className="bg-secondary border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tcp">TCP</SelectItem>
                      <SelectItem value="udp">UDP</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="listen-port">Listen Port</Label>
                  <Input
                    id="listen-port"
                    type="number"
                    placeholder="3306"
                    value={newStream.listenPort}
                    onChange={(e) =>
                      setNewStream((prev) => ({ ...prev, listenPort: e.target.value }))
                    }
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="upstream">Upstream Server</Label>
                <Input
                  id="upstream"
                  placeholder="db.internal:3306"
                  value={newStream.upstream}
                  onChange={(e) =>
                    setNewStream((prev) => ({ ...prev, upstream: e.target.value }))
                  }
                  className="bg-secondary border-border"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={addStream}>Create Stream</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Boxes className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search streams..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 bg-secondary border-border"
        />
      </div>

      {/* Streams List */}
      <div className="grid gap-4">
        {filteredStreams.map((stream) => (
          <Card key={stream.id} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center",
                      stream.status === "enabled" ? "bg-primary/10" : "bg-secondary"
                    )}
                  >
                    <Boxes
                      className={cn(
                        "w-5 h-5",
                        stream.status === "enabled"
                          ? "text-primary"
                          : "text-muted-foreground"
                      )}
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{stream.name}</span>
                      <span className="text-xs px-2 py-0.5 rounded bg-secondary text-muted-foreground uppercase">
                        {stream.protocol}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                      <span>:{stream.listenPort}</span>
                      <ArrowRight className="w-4 h-4" />
                      <span>{stream.upstream}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span
                    className={cn(
                      "flex items-center gap-1 text-sm",
                      stream.status === "enabled" ? "text-primary" : "text-muted-foreground"
                    )}
                  >
                    {stream.status === "enabled" ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <XCircle className="w-4 h-4" />
                    )}
                    <span className="hidden sm:inline">
                      {stream.status === "enabled" ? "Enabled" : "Disabled"}
                    </span>
                  </span>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem className="gap-2">
                        <Pencil className="w-4 h-4" />
                        Edit Configuration
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="gap-2"
                        onClick={() => toggleStreamStatus(stream.id)}
                      >
                        <Power className="w-4 h-4" />
                        {stream.status === "enabled" ? "Disable" : "Enable"}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="gap-2 text-destructive"
                        onClick={() => deleteStream(stream.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredStreams.length === 0 && (
          <Card className="bg-card border-border">
            <CardContent className="p-8 text-center">
              <Boxes className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No streams found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
