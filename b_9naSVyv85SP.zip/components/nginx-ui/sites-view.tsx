"use client";

import { useState } from "react";
import {
  Globe,
  Plus,
  MoreVertical,
  CheckCircle2,
  XCircle,
  Shield,
  ExternalLink,
  Pencil,
  Trash2,
  Power,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface Site {
  id: string;
  domain: string;
  status: "enabled" | "disabled";
  ssl: boolean;
  sslExpiry?: string;
  upstream?: string;
  lastModified: string;
}

const initialSites: Site[] = [
  {
    id: "1",
    domain: "example.com",
    status: "enabled",
    ssl: true,
    sslExpiry: "2025-06-15",
    upstream: "127.0.0.1:3000",
    lastModified: "2024-01-15",
  },
  {
    id: "2",
    domain: "api.example.com",
    status: "enabled",
    ssl: true,
    sslExpiry: "2025-06-15",
    upstream: "127.0.0.1:8080",
    lastModified: "2024-01-10",
  },
  {
    id: "3",
    domain: "staging.example.com",
    status: "disabled",
    ssl: false,
    upstream: "127.0.0.1:3001",
    lastModified: "2024-01-08",
  },
  {
    id: "4",
    domain: "blog.example.com",
    status: "enabled",
    ssl: true,
    sslExpiry: "2025-03-20",
    lastModified: "2024-01-05",
  },
  {
    id: "5",
    domain: "admin.example.com",
    status: "enabled",
    ssl: true,
    sslExpiry: "2025-06-15",
    upstream: "127.0.0.1:4000",
    lastModified: "2024-01-02",
  },
];

export function SitesView() {
  const [sites, setSites] = useState<Site[]>(initialSites);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newDomain, setNewDomain] = useState("");

  const filteredSites = sites.filter((site) =>
    site.domain.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSiteStatus = (id: string) => {
    setSites((prev) =>
      prev.map((site) =>
        site.id === id
          ? { ...site, status: site.status === "enabled" ? "disabled" : "enabled" }
          : site
      )
    );
  };

  const deleteSite = (id: string) => {
    setSites((prev) => prev.filter((site) => site.id !== id));
  };

  const addSite = () => {
    if (newDomain.trim()) {
      setSites((prev) => [
        {
          id: String(Date.now()),
          domain: newDomain.trim(),
          status: "disabled",
          ssl: false,
          lastModified: new Date().toISOString().split("T")[0],
        },
        ...prev,
      ]);
      setNewDomain("");
      setIsAddDialogOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Sites</h2>
          <p className="text-sm text-muted-foreground">
            Manage your Nginx server blocks and virtual hosts
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Site
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Add New Site</DialogTitle>
              <DialogDescription>
                Create a new server block configuration for your domain.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="domain">Domain Name</Label>
                <Input
                  id="domain"
                  placeholder="example.com"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  className="bg-secondary border-border"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={addSite}>Create Site</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search sites..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9 bg-secondary border-border"
        />
      </div>

      {/* Sites List */}
      <div className="grid gap-4">
        {filteredSites.map((site) => (
          <Card key={site.id} className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center",
                      site.status === "enabled" ? "bg-primary/10" : "bg-secondary"
                    )}
                  >
                    <Globe
                      className={cn(
                        "w-5 h-5",
                        site.status === "enabled" ? "text-primary" : "text-muted-foreground"
                      )}
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{site.domain}</span>
                      {site.ssl && (
                        <Shield className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <div className="flex items-center gap-3 mt-1">
                      <span
                        className={cn(
                          "flex items-center gap-1 text-xs",
                          site.status === "enabled" ? "text-primary" : "text-muted-foreground"
                        )}
                      >
                        {site.status === "enabled" ? (
                          <CheckCircle2 className="w-3 h-3" />
                        ) : (
                          <XCircle className="w-3 h-3" />
                        )}
                        {site.status === "enabled" ? "Enabled" : "Disabled"}
                      </span>
                      {site.upstream && (
                        <span className="text-xs text-muted-foreground">
                          → {site.upstream}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {site.ssl && site.sslExpiry && (
                    <span className="text-xs text-muted-foreground hidden sm:block">
                      SSL expires {site.sslExpiry}
                    </span>
                  )}
                  <Button variant="ghost" size="icon" asChild>
                    <a href={`https://${site.domain}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4 text-muted-foreground" />
                    </a>
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem className="gap-2">
                        <Pencil className="w-4 h-4" />
                        Edit Configuration
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="gap-2"
                        onClick={() => toggleSiteStatus(site.id)}
                      >
                        <Power className="w-4 h-4" />
                        {site.status === "enabled" ? "Disable" : "Enable"}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        className="gap-2 text-destructive"
                        onClick={() => deleteSite(site.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredSites.length === 0 && (
          <Card className="bg-card border-border">
            <CardContent className="p-8 text-center">
              <Globe className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No sites found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
