"use client";

import {
  Server,
  Cpu,
  MemoryStick,
  HardDrive,
  Network,
  Activity,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

const cpuData = [
  { time: "00:00", value: 23 },
  { time: "04:00", value: 18 },
  { time: "08:00", value: 45 },
  { time: "12:00", value: 62 },
  { time: "16:00", value: 55 },
  { time: "20:00", value: 38 },
  { time: "Now", value: 32 },
];

const memoryData = [
  { time: "00:00", value: 4.2 },
  { time: "04:00", value: 4.1 },
  { time: "08:00", value: 5.8 },
  { time: "12:00", value: 6.4 },
  { time: "16:00", value: 6.1 },
  { time: "20:00", value: 5.2 },
  { time: "Now", value: 4.8 },
];

const networkData = [
  { time: "00:00", inbound: 120, outbound: 80 },
  { time: "04:00", inbound: 85, outbound: 55 },
  { time: "08:00", inbound: 340, outbound: 220 },
  { time: "12:00", inbound: 520, outbound: 380 },
  { time: "16:00", inbound: 480, outbound: 350 },
  { time: "20:00", inbound: 280, outbound: 180 },
  { time: "Now", inbound: 195, outbound: 125 },
];

const requestsData = [
  { time: "00:00", requests: 1200 },
  { time: "04:00", requests: 800 },
  { time: "08:00", requests: 3400 },
  { time: "12:00", requests: 5200 },
  { time: "16:00", requests: 4800 },
  { time: "20:00", requests: 2800 },
  { time: "Now", requests: 1950 },
];

export function DashboardView() {
  return (
    <div className="space-y-6">
      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Nginx Status</p>
                <div className="flex items-center gap-2 mt-1">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                  <span className="text-lg font-semibold text-foreground">Running</span>
                </div>
              </div>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Server className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>Uptime: 45 days, 12 hours</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">CPU Usage</p>
                <p className="text-2xl font-semibold text-foreground mt-1">32%</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <Cpu className="w-6 h-6 text-chart-2" />
              </div>
            </div>
            <div className="mt-3 h-1 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-chart-2 rounded-full" style={{ width: "32%" }} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Memory</p>
                <p className="text-2xl font-semibold text-foreground mt-1">4.8 GB</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <MemoryStick className="w-6 h-6 text-chart-3" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <span>of 16 GB (30%)</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Disk Usage</p>
                <p className="text-2xl font-semibold text-foreground mt-1">128 GB</p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center">
                <HardDrive className="w-6 h-6 text-chart-4" />
              </div>
            </div>
            <div className="mt-3 h-1 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-chart-4 rounded-full" style={{ width: "64%" }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Cpu className="w-4 h-4 text-chart-2" />
              CPU Usage Over Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={cpuData}>
                  <defs>
                    <linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.65 0.2 250)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.65 0.2 250)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" />
                  <XAxis dataKey="time" stroke="oklch(0.65 0.01 260)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0.01 260)" fontSize={12} unit="%" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.17 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      color: "oklch(0.95 0 0)",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="oklch(0.65 0.2 250)"
                    fill="url(#cpuGradient)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <MemoryStick className="w-4 h-4 text-chart-3" />
              Memory Usage Over Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={memoryData}>
                  <defs>
                    <linearGradient id="memGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.75 0.15 85)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.75 0.15 85)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" />
                  <XAxis dataKey="time" stroke="oklch(0.65 0.01 260)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0.01 260)" fontSize={12} unit=" GB" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.17 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      color: "oklch(0.95 0 0)",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="oklch(0.75 0.15 85)"
                    fill="url(#memGradient)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Network className="w-4 h-4 text-primary" />
              Network Traffic
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={networkData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" />
                  <XAxis dataKey="time" stroke="oklch(0.65 0.01 260)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0.01 260)" fontSize={12} unit=" MB/s" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.17 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      color: "oklch(0.95 0 0)",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="inbound"
                    stroke="oklch(0.72 0.19 145)"
                    strokeWidth={2}
                    dot={false}
                    name="Inbound"
                  />
                  <Line
                    type="monotone"
                    dataKey="outbound"
                    stroke="oklch(0.65 0.2 250)"
                    strokeWidth={2}
                    dot={false}
                    name="Outbound"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-6 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span className="text-sm text-muted-foreground">Inbound</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-chart-2" />
                <span className="text-sm text-muted-foreground">Outbound</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Activity className="w-4 h-4 text-chart-4" />
              Requests Per Minute
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={requestsData}>
                  <defs>
                    <linearGradient id="reqGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.7 0.2 300)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.7 0.2 300)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.015 260)" />
                  <XAxis dataKey="time" stroke="oklch(0.65 0.01 260)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0.01 260)" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.17 0.015 260)",
                      border: "1px solid oklch(0.28 0.015 260)",
                      borderRadius: "8px",
                      color: "oklch(0.95 0 0)",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="requests"
                    stroke="oklch(0.7 0.2 300)"
                    fill="url(#reqGradient)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Info */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-base font-medium">System Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Nginx Version</p>
              <p className="text-foreground font-medium mt-1">nginx/1.24.0</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Operating System</p>
              <p className="text-foreground font-medium mt-1">Ubuntu 22.04 LTS</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Kernel Version</p>
              <p className="text-foreground font-medium mt-1">5.15.0-91-generic</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">OpenSSL Version</p>
              <p className="text-foreground font-medium mt-1">OpenSSL 3.0.2</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
