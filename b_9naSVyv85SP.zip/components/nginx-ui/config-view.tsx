"use client";

import { useState } from "react";
import {
  FileCode,
  FolderOpen,
  ChevronRight,
  ChevronDown,
  Save,
  RotateCcw,
  Play,
  CheckCircle2,
  AlertCircle,
  File,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface FileNode {
  name: string;
  type: "file" | "folder";
  children?: FileNode[];
  content?: string;
}

const fileTree: FileNode[] = [
  {
    name: "nginx.conf",
    type: "file",
    content: `user www-data;
worker_processes auto;
pid /run/nginx.pid;
error_log /var/log/nginx/error.log;

events {
    worker_connections 1024;
    multi_accept on;
}

http {
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;

    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;

    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;

    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml application/json application/javascript;

    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}`,
  },
  {
    name: "sites-available",
    type: "folder",
    children: [
      {
        name: "example.com",
        type: "file",
        content: `server {
    listen 80;
    listen [::]:80;
    server_name example.com www.example.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name example.com www.example.com;

    ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;

    root /var/www/example.com/html;
    index index.html index.htm;

    location / {
        try_files $uri $uri/ =404;
    }

    location /api {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}`,
      },
      {
        name: "api.example.com",
        type: "file",
        content: `server {
    listen 80;
    server_name api.example.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.example.com;

    ssl_certificate /etc/letsencrypt/live/api.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $host;
    }
}`,
      },
    ],
  },
  {
    name: "sites-enabled",
    type: "folder",
    children: [
      { name: "example.com", type: "file" },
      { name: "api.example.com", type: "file" },
    ],
  },
  {
    name: "conf.d",
    type: "folder",
    children: [
      {
        name: "security.conf",
        type: "file",
        content: `# Security headers
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

# Hide Nginx version
server_tokens off;`,
      },
      {
        name: "gzip.conf",
        type: "file",
        content: `# Gzip Settings
gzip on;
gzip_disable "msie6";
gzip_vary on;
gzip_proxied any;
gzip_comp_level 6;
gzip_buffers 16 8k;
gzip_http_version 1.1;
gzip_min_length 256;
gzip_types
    application/atom+xml
    application/javascript
    application/json
    application/ld+json
    application/manifest+json
    application/rss+xml
    application/vnd.geo+json
    application/vnd.ms-fontobject
    application/x-font-ttf
    application/x-web-app-manifest+json
    application/xhtml+xml
    application/xml
    font/opentype
    image/bmp
    image/svg+xml
    image/x-icon
    text/cache-manifest
    text/css
    text/plain
    text/vcard
    text/vnd.rim.location.xloc
    text/vtt
    text/x-component
    text/x-cross-domain-policy;`,
      },
    ],
  },
];

interface TreeItemProps {
  node: FileNode;
  level: number;
  selectedFile: string | null;
  onSelect: (name: string, content?: string) => void;
}

function TreeItem({ node, level, selectedFile, onSelect }: TreeItemProps) {
  const [isOpen, setIsOpen] = useState(level === 0);

  if (node.type === "folder") {
    return (
      <div>
        <button
          className="flex items-center gap-2 w-full px-2 py-1.5 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary rounded transition-colors"
          style={{ paddingLeft: `${level * 12 + 8}px` }}
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? (
            <ChevronDown className="w-4 h-4 shrink-0" />
          ) : (
            <ChevronRight className="w-4 h-4 shrink-0" />
          )}
          <FolderOpen className="w-4 h-4 shrink-0 text-chart-3" />
          <span>{node.name}</span>
        </button>
        {isOpen && node.children && (
          <div>
            {node.children.map((child) => (
              <TreeItem
                key={child.name}
                node={child}
                level={level + 1}
                selectedFile={selectedFile}
                onSelect={onSelect}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <button
      className={cn(
        "flex items-center gap-2 w-full px-2 py-1.5 text-sm rounded transition-colors",
        selectedFile === node.name
          ? "bg-primary/10 text-primary"
          : "text-muted-foreground hover:text-foreground hover:bg-secondary"
      )}
      style={{ paddingLeft: `${level * 12 + 8}px` }}
      onClick={() => onSelect(node.name, node.content)}
    >
      <File className="w-4 h-4 shrink-0" />
      <span>{node.name}</span>
    </button>
  );
}

export function ConfigView() {
  const [selectedFile, setSelectedFile] = useState<string | null>("nginx.conf");
  const [content, setContent] = useState(fileTree[0].content || "");
  const [testResult, setTestResult] = useState<"success" | "error" | null>(null);

  const handleSelect = (name: string, fileContent?: string) => {
    setSelectedFile(name);
    if (fileContent) {
      setContent(fileContent);
    }
    setTestResult(null);
  };

  const handleTest = () => {
    // Simulate test
    setTestResult(Math.random() > 0.2 ? "success" : "error");
  };

  return (
    <div className="flex gap-6 h-[calc(100vh-180px)]">
      {/* File Tree */}
      <Card className="w-64 shrink-0 bg-card border-border overflow-hidden">
        <CardHeader className="py-3 px-4 border-b border-border">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <FileCode className="w-4 h-4 text-primary" />
            /etc/nginx
          </CardTitle>
        </CardHeader>
        <CardContent className="p-2 overflow-y-auto h-[calc(100%-52px)]">
          {fileTree.map((node) => (
            <TreeItem
              key={node.name}
              node={node}
              level={0}
              selectedFile={selectedFile}
              onSelect={handleSelect}
            />
          ))}
        </CardContent>
      </Card>

      {/* Editor */}
      <Card className="flex-1 bg-card border-border overflow-hidden flex flex-col">
        <CardHeader className="py-3 px-4 border-b border-border flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            {selectedFile ? (
              <>
                <File className="w-4 h-4 text-muted-foreground" />
                {selectedFile}
              </>
            ) : (
              "Select a file"
            )}
          </CardTitle>
          <div className="flex items-center gap-2">
            {testResult && (
              <div
                className={cn(
                  "flex items-center gap-1 text-sm px-2 py-1 rounded",
                  testResult === "success"
                    ? "bg-primary/10 text-primary"
                    : "bg-destructive/10 text-destructive"
                )}
              >
                {testResult === "success" ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Syntax OK</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4" />
                    <span>Syntax Error</span>
                  </>
                )}
              </div>
            )}
            <Button variant="outline" size="sm" className="gap-2" onClick={handleTest}>
              <Play className="w-4 h-4" />
              Test
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <RotateCcw className="w-4 h-4" />
              Reset
            </Button>
            <Button size="sm" className="gap-2">
              <Save className="w-4 h-4" />
              Save
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0 flex-1 overflow-hidden">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full h-full p-4 bg-background font-mono text-sm text-foreground resize-none focus:outline-none"
            spellCheck={false}
          />
        </CardContent>
      </Card>
    </div>
  );
}
