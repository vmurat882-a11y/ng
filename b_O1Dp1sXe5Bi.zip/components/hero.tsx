import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight, Terminal, CheckCircle2 } from "lucide-react";

const stats = [
  { label: "Supported OS", value: "7+" },
  { label: "GitHub Stars", value: "100+" },
  { label: "Latest Version", value: "v5.4.0" },
  { label: "License", value: "Apache 2.0" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/10 via-background to-background" />
        <div className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full bg-accent/5 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-64 w-64 rounded-full bg-accent/5 blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground">
            <span className="flex h-2 w-2 rounded-full bg-green-500" />
            Version 5.4.0 Released
          </div>

          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Automate Bitbucket Installation with{" "}
            <span className="text-accent">Ansible</span>
          </h1>

          <p className="mt-6 text-pretty text-lg leading-relaxed text-muted-foreground">
            Production-ready Ansible role for deploying Atlassian Bitbucket
            Server. Supports Ubuntu, AlmaLinux, Debian, Fedora, CentOS, openSUSE,
            and RHEL with automated configuration and best practices.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" asChild>
              <Link href="#config">
                Configure Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="#docs">
                <Terminal className="mr-2 h-4 w-4" />
                View Documentation
              </Link>
            </Button>
          </div>

          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Multi-platform support
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Idempotent deployment
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Production tested
            </div>
          </div>
        </div>

        <div className="mx-auto mt-16 max-w-4xl">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-lg border border-border bg-card p-6 text-center"
              >
                <div className="text-2xl font-bold text-foreground">
                  {stat.value}
                </div>
                <div className="mt-1 text-sm text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mx-auto mt-12 max-w-2xl rounded-lg border border-border bg-card p-4">
          <div className="flex items-center gap-2 border-b border-border pb-3">
            <div className="flex gap-1.5">
              <div className="h-3 w-3 rounded-full bg-red-500/80" />
              <div className="h-3 w-3 rounded-full bg-yellow-500/80" />
              <div className="h-3 w-3 rounded-full bg-green-500/80" />
            </div>
            <span className="text-xs text-muted-foreground">terminal</span>
          </div>
          <pre className="mt-4 overflow-x-auto text-sm">
            <code className="text-muted-foreground">
              <span className="text-accent">$</span>{" "}
              ansible-galaxy role install alvistack.bitbucket{"\n"}
              <span className="text-muted-foreground/60">
                - downloading role &apos;bitbucket&apos;, owned by alvistack
              </span>
              {"\n"}
              <span className="text-muted-foreground/60">
                - downloading role from https://github.com/alvistack/...
              </span>
              {"\n"}
              <span className="text-green-500">
                - alvistack.bitbucket (5.4.0) was installed successfully
              </span>
            </code>
          </pre>
        </div>
      </div>
    </section>
  );
}
