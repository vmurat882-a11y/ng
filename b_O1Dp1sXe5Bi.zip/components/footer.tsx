import Link from "next/link";
import { Github, ExternalLink, Heart } from "lucide-react";

const footerLinks = {
  resources: [
    { name: "Documentation", href: "#docs" },
    { name: "Configuration", href: "#config" },
    { name: "Playbook Preview", href: "#playbook" },
    { name: "Changelog", href: "https://github.com/alvistack/ansible-role-bitbucket/releases" },
  ],
  community: [
    { name: "GitHub", href: "https://github.com/alvistack/ansible-role-bitbucket" },
    { name: "Issues", href: "https://github.com/alvistack/ansible-role-bitbucket/issues" },
    { name: "Pull Requests", href: "https://github.com/alvistack/ansible-role-bitbucket/pulls" },
    { name: "Ansible Galaxy", href: "https://galaxy.ansible.com/alvistack/bitbucket" },
  ],
  alvistack: [
    { name: "AlviStack", href: "https://github.com/alvistack" },
    { name: "Other Roles", href: "https://github.com/orgs/alvistack/repositories" },
    { name: "Docker Images", href: "https://hub.docker.com/u/alvistack" },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent">
                <span className="text-sm font-bold text-accent-foreground">A</span>
              </div>
              <span className="font-semibold text-foreground">AlviStack</span>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Open source Ansible roles and Docker images for enterprise-ready
              infrastructure automation.
            </p>
            <div className="mt-4 flex items-center gap-4">
              <Link
                href="https://github.com/alvistack/ansible-role-bitbucket"
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground transition-colors hover:text-foreground"
              >
                <Github className="h-5 w-5" />
                <span className="sr-only">GitHub</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground">Resources</h3>
            <ul className="mt-4 space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
                    {...(link.href.startsWith("http") && {
                      target: "_blank",
                      rel: "noopener noreferrer",
                    })}
                  >
                    {link.name}
                    {link.href.startsWith("http") && (
                      <ExternalLink className="h-3 w-3" />
                    )}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground">Community</h3>
            <ul className="mt-4 space-y-3">
              {footerLinks.community.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.name}
                    <ExternalLink className="h-3 w-3" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground">AlviStack</h3>
            <ul className="mt-4 space-y-3">
              {footerLinks.alvistack.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.name}
                    <ExternalLink className="h-3 w-3" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            Released under the Apache License 2.0
          </p>
          <p className="flex items-center gap-1 text-sm text-muted-foreground">
            Made with <Heart className="h-4 w-4 text-red-500" /> by AlviStack
          </p>
        </div>
      </div>
    </footer>
  );
}
