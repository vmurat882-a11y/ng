import {
  Server,
  Shield,
  Zap,
  Package,
  RefreshCw,
  Settings,
  Database,
  Lock,
} from "lucide-react";

const features = [
  {
    icon: Server,
    title: "Multi-Platform Support",
    description:
      "Deploy on Ubuntu, AlmaLinux, Debian, Fedora, CentOS, openSUSE, and RHEL with consistent configuration across all platforms.",
  },
  {
    icon: Shield,
    title: "Security Best Practices",
    description:
      "Built-in security configurations including SSL/TLS setup, firewall rules, and secure default settings for production environments.",
  },
  {
    icon: Zap,
    title: "Idempotent Deployment",
    description:
      "Run the playbook multiple times safely. Changes are only applied when necessary, ensuring consistent state every time.",
  },
  {
    icon: Package,
    title: "Automated Dependencies",
    description:
      "Automatically handles Java JDK installation, PostgreSQL setup, and all required dependencies for Bitbucket Server.",
  },
  {
    icon: RefreshCw,
    title: "Easy Updates",
    description:
      "Seamlessly upgrade Bitbucket versions with built-in backup and rollback capabilities for zero-downtime deployments.",
  },
  {
    icon: Settings,
    title: "Flexible Configuration",
    description:
      "Extensive customization through Ansible variables. Configure memory limits, ports, proxy settings, and more.",
  },
  {
    icon: Database,
    title: "Database Integration",
    description:
      "Supports PostgreSQL and MySQL databases with automated schema creation and connection configuration.",
  },
  {
    icon: Lock,
    title: "Apache 2.0 License",
    description:
      "Open source and free to use. Contribute, modify, and distribute without restrictions for your infrastructure needs.",
  },
];

export function Features() {
  return (
    <section id="features" className="border-t border-border py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Everything you need for Bitbucket deployment
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            A comprehensive Ansible role designed for production deployments
            with enterprise-grade features and reliability.
          </p>
        </div>

        <div className="mx-auto mt-16 grid max-w-5xl gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group rounded-lg border border-border bg-card p-6 transition-colors hover:border-accent/50 hover:bg-card/80"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-accent/10 text-accent transition-colors group-hover:bg-accent group-hover:text-accent-foreground">
                <feature.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
