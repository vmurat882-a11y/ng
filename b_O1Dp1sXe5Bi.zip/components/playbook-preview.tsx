"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Play, Pause, RotateCcw, CheckCircle2, Circle, Loader2 } from "lucide-react";

interface Task {
  id: number;
  name: string;
  role: string;
  status: "pending" | "running" | "completed" | "skipped";
  duration?: number;
}

const initialTasks: Task[] = [
  { id: 1, name: "Gathering Facts", role: "GATHERING FACTS", status: "pending" },
  { id: 2, name: "Include OS-specific variables", role: "alvistack.bitbucket", status: "pending" },
  { id: 3, name: "Install required packages", role: "alvistack.bitbucket", status: "pending" },
  { id: 4, name: "Create bitbucket group", role: "alvistack.bitbucket", status: "pending" },
  { id: 5, name: "Create bitbucket user", role: "alvistack.bitbucket", status: "pending" },
  { id: 6, name: "Download Bitbucket archive", role: "alvistack.bitbucket", status: "pending" },
  { id: 7, name: "Extract Bitbucket archive", role: "alvistack.bitbucket", status: "pending" },
  { id: 8, name: "Create application directories", role: "alvistack.bitbucket", status: "pending" },
  { id: 9, name: "Configure bitbucket.properties", role: "alvistack.bitbucket", status: "pending" },
  { id: 10, name: "Configure JVM settings", role: "alvistack.bitbucket", status: "pending" },
  { id: 11, name: "Create systemd service", role: "alvistack.bitbucket", status: "pending" },
  { id: 12, name: "Enable Bitbucket service", role: "alvistack.bitbucket", status: "pending" },
  { id: 13, name: "Start Bitbucket service", role: "alvistack.bitbucket", status: "pending" },
  { id: 14, name: "Wait for Bitbucket startup", role: "alvistack.bitbucket", status: "pending" },
  { id: 15, name: "Verify Bitbucket is running", role: "POST TASKS", status: "pending" },
];

export function PlaybookPreview() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [isRunning, setIsRunning] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [elapsed, setElapsed] = useState(0);

  const completedCount = tasks.filter((t) => t.status === "completed").length;
  const progress = (completedCount / tasks.length) * 100;

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && currentIndex < tasks.length) {
      interval = setInterval(() => {
        setElapsed((prev) => prev + 100);
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isRunning, currentIndex, tasks.length]);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (isRunning && currentIndex < tasks.length) {
      const delay = Math.random() * 800 + 400;
      timeout = setTimeout(() => {
        setTasks((prev) =>
          prev.map((task, i) => {
            if (i === currentIndex) {
              return { ...task, status: "completed", duration: delay };
            }
            if (i === currentIndex + 1) {
              return { ...task, status: "running" };
            }
            return task;
          })
        );
        setCurrentIndex((prev) => prev + 1);
        if (currentIndex >= tasks.length - 1) {
          setIsRunning(false);
        }
      }, delay);
    }
    return () => clearTimeout(timeout);
  }, [isRunning, currentIndex, tasks.length]);

  const startPlaybook = () => {
    if (currentIndex === -1 || currentIndex >= tasks.length - 1) {
      setTasks(initialTasks.map((t, i) => ({
        ...t,
        status: i === 0 ? "running" : "pending",
        duration: undefined,
      })));
      setCurrentIndex(0);
      setElapsed(0);
    }
    setIsRunning(true);
  };

  const pausePlaybook = () => {
    setIsRunning(false);
  };

  const resetPlaybook = () => {
    setIsRunning(false);
    setCurrentIndex(-1);
    setElapsed(0);
    setTasks(initialTasks);
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  return (
    <section id="playbook" className="border-t border-border py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Interactive Playbook Preview
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            See how the Ansible role executes tasks in real-time simulation.
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-4xl">
          <div className="overflow-hidden rounded-lg border border-border bg-card">
            <div className="flex items-center justify-between border-b border-border bg-secondary/30 px-4 py-3">
              <div className="flex items-center gap-4">
                <div className="flex gap-1.5">
                  <div className="h-3 w-3 rounded-full bg-red-500/80" />
                  <div className="h-3 w-3 rounded-full bg-yellow-500/80" />
                  <div className="h-3 w-3 rounded-full bg-green-500/80" />
                </div>
                <span className="text-sm text-muted-foreground">
                  ansible-playbook bitbucket.yml
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {formatTime(elapsed)}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={resetPlaybook}
                  disabled={currentIndex === -1}
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
                {isRunning ? (
                  <Button variant="outline" size="sm" onClick={pausePlaybook}>
                    <Pause className="mr-2 h-4 w-4" />
                    Pause
                  </Button>
                ) : (
                  <Button size="sm" onClick={startPlaybook}>
                    <Play className="mr-2 h-4 w-4" />
                    {currentIndex === -1 ? "Run" : currentIndex >= tasks.length - 1 ? "Restart" : "Resume"}
                  </Button>
                )}
              </div>
            </div>

            <div className="border-b border-border bg-secondary/20 px-4 py-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  Progress: {completedCount}/{tasks.length} tasks
                </span>
                <span className="text-muted-foreground">
                  {Math.round(progress)}%
                </span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-secondary">
                <div
                  className="h-full bg-accent transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            <div className="max-h-[400px] overflow-y-auto p-4 font-mono text-sm">
              <div className="text-muted-foreground">
                <span className="text-green-500">PLAY</span> [Deploy Atlassian Bitbucket Server]
                {" "}{"*".repeat(40)}
              </div>
              <div className="mt-4 space-y-1">
                {tasks.map((task, index) => (
                  <div
                    key={task.id}
                    className={cn(
                      "flex items-start gap-2 py-1 transition-opacity",
                      task.status === "pending" && index > currentIndex + 1 && "opacity-40"
                    )}
                  >
                    <div className="mt-0.5 flex-shrink-0">
                      {task.status === "completed" ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : task.status === "running" ? (
                        <Loader2 className="h-4 w-4 animate-spin text-accent" />
                      ) : (
                        <Circle className="h-4 w-4 text-muted-foreground/50" />
                      )}
                    </div>
                    <div className="flex-1">
                      <span
                        className={cn(
                          task.status === "completed" && "text-green-500",
                          task.status === "running" && "text-accent",
                          task.status === "pending" && "text-muted-foreground"
                        )}
                      >
                        TASK
                      </span>{" "}
                      <span className="text-muted-foreground">
                        [{task.role}] {task.name}
                      </span>
                      {task.status === "completed" && (
                        <span className="ml-2 text-green-500">
                          ok: [bitbucket-server]
                        </span>
                      )}
                    </div>
                    {task.duration && (
                      <span className="flex-shrink-0 text-muted-foreground/60">
                        {(task.duration / 1000).toFixed(2)}s
                      </span>
                    )}
                  </div>
                ))}
              </div>
              {completedCount === tasks.length && (
                <div className="mt-6 space-y-2">
                  <div className="text-muted-foreground">
                    <span className="text-green-500">PLAY RECAP</span>
                    {" "}{"*".repeat(50)}
                  </div>
                  <div className="text-muted-foreground">
                    bitbucket-server : <span className="text-green-500">ok={tasks.length}</span>{" "}
                    <span className="text-yellow-500">changed=8</span>{" "}
                    <span className="text-muted-foreground/60">unreachable=0</span>{" "}
                    <span className="text-muted-foreground/60">failed=0</span>{" "}
                    <span className="text-muted-foreground/60">skipped=0</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
