"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Copy, Check, ChevronRight, Book, Terminal, Cog } from "lucide-react";
import { Button } from "@/components/ui/button";

const tabs = [
  { id: "quickstart", label: "Quick Start", icon: Terminal },
  { id: "requirements", label: "Requirements", icon: Cog },
  { id: "variables", label: "Variables", icon: Book },
];

const codeExamples: Record<string, { title: string; code: string; language: string }[]> = {
  quickstart: [
    {
      title: "Install the role from Ansible Galaxy",
      code: `# Install the role from Ansible Galaxy
ansible-galaxy role install alvistack.bitbucket

# Or include in requirements.yml
- name: alvistack.bitbucket
  src: https://github.com/alvistack/ansible-role-bitbucket
  version: v5.4.0`,
      language: "bash",
    },
    {
      title: "Create a playbook",
      code: `---
# playbooks/bitbucket.yml
- hosts: bitbucket_servers
  become: true
  roles:
    - role: alvistack.bitbucket
      vars:
        bitbucket_version: "8.19.0"
        bitbucket_jvm_maximum_memory: "2048m"
        bitbucket_catalina_connector_port: 7990`,
      language: "yaml",
    },
    {
      title: "Run the playbook",
      code: `# Run the playbook
ansible-playbook -i inventory/hosts playbooks/bitbucket.yml

# With extra variables
ansible-playbook -i inventory/hosts playbooks/bitbucket.yml \\
  -e "bitbucket_version=8.19.0" \\
  -e "bitbucket_jvm_maximum_memory=4096m"`,
      language: "bash",
    },
  ],
  requirements: [
    {
      title: "System Requirements",
      code: `# Minimum Requirements
- Ansible community package 4.10+
- Python 3.8+ on target hosts
- 4GB RAM (8GB recommended for production)
- 2 CPU cores (4+ recommended)

# Supported Operating Systems
- Ubuntu 20.04, 22.04, 24.04
- AlmaLinux 8, 9
- Debian 11, 12
- Fedora 39, 40
- CentOS Stream 8, 9
- openSUSE Leap 15.4, 15.5
- RHEL 8, 9`,
      language: "text",
    },
    {
      title: "Dependencies",
      code: `# Role dependencies (auto-installed)
dependencies:
  - role: alvistack.openjdk
  - role: alvistack.git

# Database options (choose one)
# PostgreSQL (recommended)
- role: alvistack.postgres

# Or MySQL/MariaDB
- role: alvistack.mariadb`,
      language: "yaml",
    },
  ],
  variables: [
    {
      title: "Core Configuration Variables",
      code: `# Bitbucket Version
bitbucket_version: "8.19.0"

# JVM Memory Settings
bitbucket_jvm_minimum_memory: "1024m"
bitbucket_jvm_maximum_memory: "2048m"

# Server Configuration
bitbucket_catalina_connector_port: 7990
bitbucket_catalina_connector_scheme: "http"
bitbucket_catalina_connector_secure: false

# Installation Paths
bitbucket_home: "/var/atlassian/application-data/bitbucket"
bitbucket_catalina_base: "/opt/atlassian/bitbucket"`,
      language: "yaml",
    },
    {
      title: "Database Configuration",
      code: `# PostgreSQL (default)
bitbucket_jdbc_driver: "org.postgresql.Driver"
bitbucket_jdbc_url: "jdbc:postgresql://localhost:5432/bitbucket"
bitbucket_jdbc_username: "bitbucket"
bitbucket_jdbc_password: "your_secure_password"

# Proxy Configuration (for reverse proxy)
bitbucket_catalina_connector_proxyname: "bitbucket.example.com"
bitbucket_catalina_connector_proxyport: "443"`,
      language: "yaml",
    },
    {
      title: "Advanced Settings",
      code: `# License (optional, configure via UI)
bitbucket_license: ""

# Elasticsearch Settings
bitbucket_elasticsearch_enabled: true
bitbucket_elasticsearch_baseurl: "http://localhost:9200"

# Backup Configuration
bitbucket_backup_home: "/var/atlassian/backups/bitbucket"
bitbucket_backup_keep: 7

# SSL/TLS Configuration
bitbucket_ssl_certificate: "/etc/ssl/certs/bitbucket.crt"
bitbucket_ssl_certificate_key: "/etc/ssl/private/bitbucket.key"`,
      language: "yaml",
    },
  ],
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      className="h-8 w-8 p-0"
      onClick={copy}
    >
      {copied ? (
        <Check className="h-4 w-4 text-green-500" />
      ) : (
        <Copy className="h-4 w-4" />
      )}
      <span className="sr-only">Copy code</span>
    </Button>
  );
}

export function Documentation() {
  const [activeTab, setActiveTab] = useState("quickstart");

  return (
    <section id="docs" className="border-t border-border py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Documentation
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Get started quickly with our comprehensive guides and examples.
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-5xl">
          <div className="flex flex-wrap gap-2 border-b border-border pb-4">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors",
                  activeTab === tab.id
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <tab.icon className="h-4 w-4" />
                {tab.label}
              </button>
            ))}
          </div>

          <div className="mt-8 space-y-6">
            {codeExamples[activeTab]?.map((example, index) => (
              <div
                key={index}
                className="overflow-hidden rounded-lg border border-border bg-card"
              >
                <div className="flex items-center justify-between border-b border-border bg-secondary/30 px-4 py-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <ChevronRight className="h-4 w-4" />
                    {example.title}
                  </div>
                  <CopyButton text={example.code} />
                </div>
                <pre className="overflow-x-auto p-4 text-sm">
                  <code className="text-muted-foreground">
                    {example.code}
                  </code>
                </pre>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
