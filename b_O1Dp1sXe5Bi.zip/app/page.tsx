import { Header } from "@/components/header";
import { Hero } from "@/components/hero";
import { Features } from "@/components/features";
import { Documentation } from "@/components/documentation";
import { ConfigGenerator } from "@/components/config-generator";
import { PlaybookPreview } from "@/components/playbook-preview";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <Features />
        <Documentation />
        <ConfigGenerator />
        <PlaybookPreview />
      </main>
      <Footer />
    </div>
  );
}
